package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.InvoiceViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppLayout()
            }
        }
    }
}

// Sealed class for bottom navigation bar items
sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "الرئيسية", Icons.Default.Home)
    object Invoices : Screen("invoices", "الفواتير", Icons.Default.List)
    object Backup : Screen("backup", "النسخ والمزامنة", Icons.Default.Settings)
}

@Composable
fun MainAppLayout() {
    val navController = rememberNavController()
    val viewModel: InvoiceViewModel = viewModel()
    
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Show bottom navigation only on root destinations to avoid form overlap
    val items = listOf(
        Screen.Dashboard,
        Screen.Invoices,
        Screen.Backup
    )
    val showBottomBar = currentRoute in items.map { it.route }

    // Enforce Right-to-Left (Arabic Layout) for global navigation elements
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                AnimatedVisibility(
                    visible = showBottomBar,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = NavigationBarDefaults.Elevation
                    ) {
                        items.forEach { screen ->
                            val isSelected = currentRoute == screen.route
                            NavigationBarItem(
                                icon = { 
                                    Icon(
                                        imageVector = screen.icon, 
                                        contentDescription = screen.title 
                                    ) 
                                },
                                label = { 
                                    Text(
                                        text = screen.title,
                                        style = MaterialTheme.typography.labelMedium
                                    ) 
                                },
                                selected = isSelected,
                                onClick = {
                                    if (currentRoute != screen.route) {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Dashboard.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                // 1. Dashboard Screen route
                composable(Screen.Dashboard.route) {
                    DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToForm = { navController.navigate("form") },
                        onNavigateToList = { navController.navigate(Screen.Invoices.route) },
                        onNavigateToDetail = { id -> navController.navigate("detail/$id") }
                    )
                }

                // 2. Invoices List Screen route
                composable(Screen.Invoices.route) {
                    InvoiceListScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { id -> navController.navigate("detail/$id") },
                        onNavigateToForm = { navController.navigate("form") },
                        onNavigateToBackup = { navController.navigate(Screen.Backup.route) }
                    )
                }

                // 3. Backup and Sync Screen route
                composable(Screen.Backup.route) {
                    BackupRestoreScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // 4. Form Screen Route (Both for adding nested or editing)
                composable(
                    route = "form?id={id}",
                    arguments = listOf(
                        navArgument("id") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = null
                        }
                    )
                ) { backStackEntry ->
                    val idString = backStackEntry.arguments?.getString("id")
                    val invoiceId = idString?.toIntOrNull()
                    InvoiceFormScreen(
                        viewModel = viewModel,
                        invoiceId = invoiceId,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // 5. Details Screen Route
                composable(
                    route = "detail/{id}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.IntType }
                    )
                ) { backStackEntry ->
                    val invoiceId = backStackEntry.arguments?.getInt("id") ?: 0
                    InvoiceDetailScreen(
                        viewModel = viewModel,
                        invoiceId = invoiceId,
                        onNavigateBack = { navController.popBackStack() },
                        onNavigateToEdit = { id -> navController.navigate("form?id=$id") }
                    )
                }
            }
        }
    }
}
