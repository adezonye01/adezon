package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceNumber: String,
    val customerName: String,
    val deviceDescription: String,
    val maintenanceCost: Double,
    val partsCost: Double,
    val programmingCost: Double,
    val deliveryDate: Long,
    val receivedDate: Long = System.currentTimeMillis(),
    val notes: String = "",
    val status: String = "قيد الصيانة" // Constants: "قيد الصيانة", "جاهز للتسليم", "تم التسليم"
) {
    // Total price is simply the sum of all individual costs
    val totalCost: Double
        get() = maintenanceCost + partsCost + programmingCost
}
