package com.example.data

import kotlinx.coroutines.flow.Flow

class InvoiceRepository(private val invoiceDao: InvoiceDao) {
    val allInvoices: Flow<List<Invoice>> = invoiceDao.getAllInvoices()

    suspend fun getInvoiceById(id: Int): Invoice? {
        return invoiceDao.getInvoiceById(id)
    }

    suspend fun getInvoiceByNumber(invoiceNumber: String): Invoice? {
        return invoiceDao.getInvoiceByNumber(invoiceNumber)
    }

    suspend fun insertInvoice(invoice: Invoice): Long {
        return invoiceDao.insertInvoice(invoice)
    }

    suspend fun updateInvoice(invoice: Invoice) {
        invoiceDao.updateInvoice(invoice)
    }

    suspend fun deleteInvoice(invoice: Invoice) {
        invoiceDao.deleteInvoice(invoice)
    }

    suspend fun deleteInvoiceById(id: Int) {
        invoiceDao.deleteInvoiceById(id)
    }
    
    suspend fun clearAllInvoices() {
        invoiceDao.clearAllInvoices()
    }
}
