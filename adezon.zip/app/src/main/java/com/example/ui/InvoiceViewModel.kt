package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Invoice
import com.example.data.InvoiceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class InvoiceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: InvoiceRepository
    
    // UI state states
    val allInvoices: StateFlow<List<Invoice>>
    
    // Filter & Search states
    val searchQuery = MutableStateFlow("")
    val statusFilter = MutableStateFlow("الكل") // "الكل", "قيد الصيانة", "جاهز للتسليم", "تم التسليم"
    
    // Filtered list of invoices
    val filteredInvoices: StateFlow<List<Invoice>>

    // Google Sign-In Simulation State
    val isGoogleLinked = MutableStateFlow(false)
    val googleEmail = MutableStateFlow("")
    val googleName = MutableStateFlow("")

    // Operation messages (e.g. backup success, error, etc.)
    val operationStatus = MutableStateFlow<String?>(null)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = InvoiceRepository(database.invoiceDao())
        allInvoices = repository.allInvoices.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
        filteredInvoices = combine(allInvoices, searchQuery, statusFilter) { list, query, filter ->
            list.filter { invoice ->
                val matchesQuery = invoice.customerName.contains(query, ignoreCase = true) ||
                        invoice.deviceDescription.contains(query, ignoreCase = true) ||
                        invoice.invoiceNumber.contains(query, ignoreCase = true)
                
                val matchesFilter = if (filter == "الكل") true else invoice.status == filter
                
                matchesQuery && matchesFilter
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // --- Core Database operations ---
    
    fun createInvoice(
        customerName: String,
        deviceDescription: String,
        maintenanceCost: Double,
        partsCost: Double,
        programmingCost: Double,
        deliveryDate: Long,
        notes: String,
        status: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            val invoiceNumber = generateNextInvoiceNumber()
            val newInvoice = Invoice(
                invoiceNumber = invoiceNumber,
                customerName = customerName,
                deviceDescription = deviceDescription,
                maintenanceCost = maintenanceCost,
                partsCost = partsCost,
                programmingCost = programmingCost,
                deliveryDate = deliveryDate,
                notes = notes,
                status = status
            )
            repository.insertInvoice(newInvoice)
            onComplete()
        }
    }

    fun updateInvoice(invoice: Invoice, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.updateInvoice(invoice)
            onComplete()
        }
    }

    fun deleteInvoice(id: Int) {
        viewModelScope.launch {
            repository.deleteInvoiceById(id)
        }
    }

    // Generate unique sequential invoice number
    private fun generateNextInvoiceNumber(): String {
        val count = allInvoices.value.size + 1
        val currentYear = SimpleDateFormat("yyyy", Locale.US).format(Date())
        return String.format(Locale.US, "AD-%s-%04d", currentYear, count)
    }

    // Clean status message after displaying
    fun clearStatusMessage() {
        operationStatus.value = null
    }

    // --- Backup & Restore via Uri ---

    fun exportDatabase(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val invoices = allInvoices.value
                val jsonArray = JSONArray()
                
                for (invoice in invoices) {
                    val obj = JSONObject()
                    obj.put("invoiceNumber", invoice.invoiceNumber)
                    obj.put("customerName", invoice.customerName)
                    obj.put("deviceDescription", invoice.deviceDescription)
                    obj.put("maintenanceCost", invoice.maintenanceCost)
                    obj.put("partsCost", invoice.partsCost)
                    obj.put("programmingCost", invoice.programmingCost)
                    obj.put("deliveryDate", invoice.deliveryDate)
                    obj.put("receivedDate", invoice.receivedDate)
                    obj.put("notes", invoice.notes)
                    obj.put("status", invoice.status)
                    jsonArray.put(obj)
                }
                
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(jsonArray.toString(4).toByteArray())
                    outputStream.flush()
                }
                operationStatus.value = "تم تصدير النسخة الاحتياطية بنجاح بنسق خارجي!"
            } catch (e: Exception) {
                operationStatus.value = "فشل في تصدير البيانات: ${e.localizedMessage}"
            }
        }
    }

    fun importDatabase(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val contentResolver = context.contentResolver
                val inputStream = contentResolver.openInputStream(uri) ?: throw Exception("تعذر فتح الملف")
                val reader = BufferedReader(InputStreamReader(inputStream))
                val stringBuilder = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    stringBuilder.append(line)
                }
                inputStream.close()
                
                val jsonArray = JSONArray(stringBuilder.toString())
                var importedCount = 0
                
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val invoiceNumber = obj.getString("invoiceNumber")
                    
                    // Prevent duplicate invoice numbers if we already have it, or overwrite
                    val existing = repository.getInvoiceByNumber(invoiceNumber)
                    val invoice = Invoice(
                        id = existing?.id ?: 0, // overwrite existing, or add new
                        invoiceNumber = invoiceNumber,
                        customerName = obj.getString("customerName"),
                        deviceDescription = obj.getString("deviceDescription"),
                        maintenanceCost = obj.getDouble("maintenanceCost"),
                        partsCost = obj.getDouble("partsCost"),
                        programmingCost = obj.getDouble("programmingCost"),
                        deliveryDate = obj.getLong("deliveryDate"),
                        receivedDate = obj.optLong("receivedDate", System.currentTimeMillis()),
                        notes = obj.optString("notes", ""),
                        status = obj.optString("status", "قيد الصيانة")
                    )
                    repository.insertInvoice(invoice)
                    importedCount++
                }
                
                operationStatus.value = "تم استعادة $importedCount فاتورة بنجاح!"
            } catch (e: Exception) {
                operationStatus.value = "فشل في استيراد النسخة الاحتياطية: ملف غير صالح أو تالف"
            }
        }
    }

    // --- Google Simulation link ---
    fun linkGoogleAccount(email: String, name: String) {
        viewModelScope.launch {
            googleEmail.value = email
            googleName.value = name
            isGoogleLinked.value = true
            operationStatus.value = "تم ربط الحساب وتحسين المزامنة السحابية بنجاح!"
        }
    }

    fun unlinkGoogleAccount() {
        viewModelScope.launch {
            googleEmail.value = ""
            googleName.value = ""
            isGoogleLinked.value = false
            operationStatus.value = "تم إلغاء ربط حساب Google بنجاح."
        }
    }
}
