package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.InvoiceViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: InvoiceViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isGoogleLinked by viewModel.isGoogleLinked.collectAsState()
    val googleEmail by viewModel.googleEmail.collectAsState()
    val googleName by viewModel.googleName.collectAsState()
    val operationStatus by viewModel.operationStatus.collectAsState()

    var showGoogleLinkDialog by remember { mutableStateOf(false) }
    var inputEmail by remember { mutableStateOf("adezonye01@gmail.com") }
    var inputName by remember { mutableStateOf("مركز أديزون للصيانة") }

    // Show Toast for operations status
    LaunchedEffect(operationStatus) {
        operationStatus?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearStatusMessage()
        }
    }

    // Picker for exporting file (Intent.ACTION_CREATE_DOCUMENT)
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                viewModel.exportDatabase(context, uri)
            }
        }
    }

    // Picker for importing file (Intent.ACTION_OPEN_DOCUMENT)
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                viewModel.importDatabase(context, uri)
            }
        }
    }

    fun launchExport() {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US)
        val dateString = sdf.format(Date())
        val fileName = "adezon_invoices_backup_$dateString.json"
        
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
        exportLauncher.launch(intent)
    }

    fun launchImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        importLauncher.launch(intent)
    }

    // Force Arabic RTL
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("المزامنة والنسخ الاحتياطي", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Google Account Integration Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            
                            Column {
                                Text(
                                    text = "ربط الحساب بـ Google",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "حفظ ومزامنة فواتير الصيانة سحابياً لحمايتها من الضياع",
                                    fontSize = 11.sp,
                                    color = ColorMuted
                                )
                            }
                        }

                        AnimatedVisibility(visible = isGoogleLinked) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ColorReady.copy(alpha = 0.1f))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ColorReady)
                                Column {
                                    Text(
                                        text = "مرتبط بنجاح: $googleName",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = ColorReady
                                    )
                                    Text(
                                        text = googleEmail,
                                        fontSize = 11.sp,
                                        color = ColorReady.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }

                        AnimatedVisibility(visible = !isGoogleLinked) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = ColorMuted)
                                Text(
                                    text = "الحساب غير مرتبط حالياً. سيتم حفظ البيانات محلياً فقط.",
                                    fontSize = 11.sp,
                                    color = ColorMuted
                                )
                            }
                        }

                        Button(
                            onClick = {
                                if (isGoogleLinked) {
                                    viewModel.unlinkGoogleAccount()
                                } else {
                                    showGoogleLinkDialog = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isGoogleLinked) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primary,
                                contentColor = if (isGoogleLinked) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isGoogleLinked) "إلغاء ربط حساب Google" else "تسجيل واقتران بحساب Google",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 2. Local/External Backup & Restore File Handler (نسخ خارجي واستعادة النسخ الاحتياطي)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ColorPending.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = ColorPending
                                )
                            }
                            
                            Column {
                                Text(
                                    text = "النسخ الاحتياطي اليدوي الاستيراد والتصدير",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "تصدير فواتير الصيانة كملف JSON آمن لحفظه خارجياً أو استعادته",
                                    fontSize = 11.sp,
                                    color = ColorMuted
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Export Button (تصدير)
                            ElevatedButton(
                                onClick = { launchExport() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("نسخ احتياطي خارجي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            // Import Button (استعادة)
                            OutlinedButton(
                                onClick = { launchImport() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("استعادة النسخ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        
                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        // Advice box on how to save backup to Google Drive
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "💡 نصيحة المزامنة السحابية للريال اليمني:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "عند ضغط 'نسخ احتياطي خارجي'، يمكنك اختيار مجلد 'Google Drive' المتوفر بالهاتف مباشرة لتخزين الملف سحابياً واستعادته في أي وقت ومن أي جهاز آخر!",
                                    fontSize = 11.sp,
                                    color = ColorMuted,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Animated Simulation Dialog for Google Linkage
        if (showGoogleLinkDialog) {
            AlertDialog(
                onDismissRequest = { showGoogleLinkDialog = false },
                title = { Text("ربط الحساب بـ Google", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("مرحباً بك في نظام أديزون السحابي. يرجى تأكيد بيانات حساب Google المراد اقترانه:")
                        
                        OutlinedTextField(
                            value = inputName,
                            onValueChange = { inputName = it },
                            label = { Text("اسم المستخدم") },
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = inputEmail,
                            onValueChange = { inputEmail = it },
                            label = { Text("البريد الإلكتروني") },
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.linkGoogleAccount(inputEmail.trim(), inputName.trim())
                            showGoogleLinkDialog = false
                        }
                    ) {
                        Text("موافق واقتران")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showGoogleLinkDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}
