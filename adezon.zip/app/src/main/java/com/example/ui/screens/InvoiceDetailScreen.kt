package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Invoice
import com.example.ui.InvoiceViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceDetailScreen(
    viewModel: InvoiceViewModel,
    invoiceId: Int,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (Int) -> Unit
) {
    val context = LocalContext.current
    val invoices by viewModel.allInvoices.collectAsState()
    
    val invoice = remember(invoiceId, invoices) {
        invoices.find { it.id == invoiceId }
    }

    // Toggle between Technician View and Customer Receipt View
    var showCustomerViewOnly by remember { mutableStateOf(true) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    if (invoice == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لم يتم العثور على الفاتورة المطلوبة")
        }
        return
    }

    val formattedReceivedDate = remember(invoice.receivedDate) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.format(Date(invoice.receivedDate))
    }

    val formattedDeliveryDate = remember(invoice.deliveryDate) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.format(Date(invoice.deliveryDate))
    }

    val statusColor = when (invoice.status) {
        "قيد الصيانة" -> ColorPending
        "جاهز للتسليم" -> ColorReady
        "تم التسليم" -> ColorDone
        else -> ColorMuted
    }

    // Force Arabic RTL
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("تفاصيل الفاتورة", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { onNavigateToEdit(invoice.id) }) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل الفاتورة")
                        }
                        IconButton(onClick = { showDeleteConfirmDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف الفاتورة")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // View Selector (Technician View vs Customer View)
                TabRow(
                    selectedTabIndex = if (showCustomerViewOnly) 0 else 1,
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = showCustomerViewOnly,
                        onClick = { showCustomerViewOnly = true },
                        text = { 
                            Text(
                                "عرض الزبون (الإجمالي فقط)", 
                                fontWeight = FontWeight.Bold, 
                                fontSize = 13.sp
                            ) 
                        }
                    )
                    Tab(
                        selected = !showCustomerViewOnly,
                        onClick = { showCustomerViewOnly = false },
                        text = { 
                            Text(
                                "عرض الفني (التفصيلي)", 
                                fontWeight = FontWeight.Bold, 
                                fontSize = 13.sp
                            ) 
                        }
                    )
                }

                // Billing / Invoice Receipt Layout
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Official Letterhead Header
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "أديزون - قسم الصيانة",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "مركز صيانة كاميرات مراقبة وتوابعها",
                                fontSize = 11.sp,
                                color = ColorMuted,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "اليمن - إب • هاتف: 04401155",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(MaterialTheme.colorScheme.outlineVariant)
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Invoice Details Block
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "رقم الفاتورة: ${formatEnglishText(invoice.invoiceNumber)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ColorMuted
                            )
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(statusColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = invoice.status,
                                    color = statusColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Metadata Rows
                        InvoiceMetaDataRow("اسم الزبون:", invoice.customerName)
                        InvoiceMetaDataRow("بيان القطعة:", invoice.deviceDescription)
                        InvoiceMetaDataRow("تاريخ الاستلام:", formatEnglishText(formattedReceivedDate))
                        InvoiceMetaDataRow("تاريخ التسليم:", formatEnglishText(formattedDeliveryDate))

                        if (invoice.notes.isNotEmpty()) {
                            InvoiceMetaDataRow("ملاحظات الورشة:", invoice.notes)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Conditional content based on selected View Mode
                        if (showCustomerViewOnly) {
                            // Hides breakdown. Only shows the final price block! (يظهر الإجمالي فقط للزبون)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "المبلغ الإجمالي المستحق:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "شامل الصيانة والأجزاء المستبدلة",
                                        fontSize = 10.sp,
                                        color = ColorMuted
                                    )
                                }
                                Text(
                                    text = "${formatEnglishNumber(invoice.totalCost.toInt())} ر.ي",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        } else {
                            // Detailed breakdown for Technician
                            Text(
                                text = "تفاصيل التكاليف التشغيلية (للفنيين فقط):",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            
                            InvoiceDetailCostRow("تكلفة الفحص واليد (صيانة الميكانيك):", invoice.maintenanceCost)
                            InvoiceDetailCostRow("سعر قطع الغيار المركّبة:", invoice.partsCost)
                            InvoiceDetailCostRow("تكلفة البرمجة والإعداد الشبكي:", invoice.programmingCost)
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "المبلــــــــغ الإجمالي للاستحقاق:",
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "(صيانة + قطع + برمجة)",
                                        fontSize = 10.sp,
                                        color = ColorMuted
                                    )
                                }
                                Text(
                                    text = "${formatEnglishNumber(invoice.totalCost.toInt())} ر.ي",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                // WhatsApp Sharing button and Actions
                Button(
                    onClick = {
                        shareInvoiceToWhatsApp(context, invoice)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF25D366), // WhatsApp Green brand color
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تصدير الفاتورة ومشاركتها عبر الواتساب",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Deletion Conformation Dialogue
        if (showDeleteConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirmDialog = false },
                title = { Text("تأكيد الحذف") },
                text = { Text("هل أنت متأكد من رغبتك في حذف الفاتورة رقم (${invoice.invoiceNumber}) نهائياً من النظام؟ لا يمكن التراجع عن هذه العملية.") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.deleteInvoice(invoice.id)
                            showDeleteConfirmDialog = false
                            onNavigateBack()
                        }
                    ) {
                        Text("نعم، احذف", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
fun InvoiceMetaDataRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = ColorMuted,
            modifier = Modifier.width(96.dp)
        )
        Text(
            text = value,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun InvoiceDetailCostRow(label: String, value: Double) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "${formatEnglishNumber(value.toInt())} ر.ي",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

// Share text generation to WhatsApp - Shows ONLY the Total price to the customer! (يظهر الإجمالي فقط للزبون)
fun shareInvoiceToWhatsApp(context: Context, invoice: Invoice) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val deliveryDateStr = sdf.format(Date(invoice.deliveryDate))
    val receivedDateStr = sdf.format(Date(invoice.receivedDate))

    // Formatted Receipt - HIDES maintenanceCost, partsCost, programmingCost!
    val receiptText = """
*🧾 فاتورة صيانة - مركز أديزون 🧾*
*أديزون - قسم الصيانة*
اليمن - إب | هاتف: 04401155
----------------------------------------
*رقم الفاتورة:* ${formatEnglishText(invoice.invoiceNumber)}
*حالة الطلب:* ${invoice.status}
*تاريخ الاستلام:* ${formatEnglishText(receivedDateStr)}
*تاريخ التسليم المتوقع:* ${formatEnglishText(deliveryDateStr)}
----------------------------------------
*الزبون الكريم:* ${invoice.customerName}
*بيان القطعة والملحقات:*
${invoice.deviceDescription}

${if (invoice.notes.isNotEmpty()) "*ملاحظات عيوب الجهاز:*\n${invoice.notes}\n----------------------------------------" else "----------------------------------------"}
*💰 الإجــمــالـي الـمـسـتـحـق:* ${formatEnglishNumber(invoice.totalCost.toInt())} ر.ي
----------------------------------------
نشكر ثقتكم بنا. يرجى إحضار هذه الرسالة عند الاستلام.
    """.trimIndent()

    try {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, receiptText)
            type = "text/plain"
        }
        
        // Give option to share via WhatsApp directly if possible or default sheet
        sendIntent.setPackage("com.whatsapp")
        
        val shareIntent = Intent.createChooser(sendIntent, "مشاركة الفاتورة للزبون:")
        context.startActivity(shareIntent)
    } catch (e: Exception) {
        // If WhatsApp specific intent fails, generic share
        val genericIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, receiptText)
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(genericIntent, "مشاركة الفاتورة:"))
    }
}
