package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Invoice
import com.example.ui.InvoiceViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceFormScreen(
    viewModel: InvoiceViewModel,
    invoiceId: Int?, // null if adding new invoice, otherwise editing existing
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val invoices by viewModel.allInvoices.collectAsState()
    
    // Find the invoice if editing
    val editingInvoice = remember(invoiceId, invoices) {
        if (invoiceId != null) {
            invoices.find { it.id == invoiceId }
        } else null
    }

    // Input States
    var customerName by remember { mutableStateOf("") }
    var deviceDescription by remember { mutableStateOf("") }
    
    // Detailed costs breakdown
    var maintenanceCostInput by remember { mutableStateOf("") }
    var partsCostInput by remember { mutableStateOf("") }
    var programmingCostInput by remember { mutableStateOf("") }
    
    var deliveryDate by remember { mutableStateOf(System.currentTimeMillis() + 86400000 * 3) } // default 3 days in future
    var notes by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("قيد الصيانة") }

    // Validation trigger
    var showValidationError by remember { mutableStateOf(false) }

    // Init values when editing
    LaunchedEffect(editingInvoice) {
        editingInvoice?.let {
            customerName = it.customerName
            deviceDescription = it.deviceDescription
            maintenanceCostInput = if (it.maintenanceCost > 0) it.maintenanceCost.toInt().toString() else ""
            partsCostInput = if (it.partsCost > 0) it.partsCost.toInt().toString() else ""
            programmingCostInput = if (it.programmingCost > 0) it.programmingCost.toInt().toString() else ""
            deliveryDate = it.deliveryDate
            notes = it.notes
            status = it.status
        }
    }

    // Parsing totals
    val maintenanceCost = maintenanceCostInput.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0
    val partsCost = partsCostInput.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0
    val programmingCost = programmingCostInput.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0
    val totalCost = maintenanceCost + partsCost + programmingCost

    val formattedDeliveryDate = remember(deliveryDate) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.format(Date(deliveryDate))
    }

    // Force Arabic RTL
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            if (editingInvoice == null) "فاتورة صيانة جديدة" else "تعديل فاتورة الصيانة",
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Customer Information card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "بيانات الزبون والجهاز",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium
                        )

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { 
                                customerName = it 
                                if (it.isNotEmpty()) showValidationError = false
                            },
                            label = { Text("اسم الزبون كاملاً *") },
                            placeholder = { Text("مثال: علي محمد صالح") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            isError = showValidationError && customerName.isEmpty()
                        )

                        OutlinedTextField(
                            value = deviceDescription,
                            onValueChange = { 
                                deviceDescription = it 
                                if (it.isNotEmpty()) showValidationError = false
                            },
                            label = { Text("بيان القطعة / الكاميرات وتوابعها *") },
                            placeholder = { Text("مثال: 4 كاميرات داهوا 2 ميجا + جهاز تسجيل DVR") },
                            modifier = Modifier.fillMaxWidth(),
                            isError = showValidationError && deviceDescription.isEmpty()
                        )
                    }
                }

                // Cost Breakdown Card (اجعل كتابة الأرقام بالإنجليزي)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "تفاصيل التكلفة ومبالغ الصيانة (ر.ي)",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium
                        )
                        
                        Text(
                            text = "* يرجى كتابة المبالغ بالأرقام الإنجليزية وسيحسب التطبيق الإجمالي للزبون تلقائياً.",
                            fontSize = 11.sp,
                            color = ColorMuted,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )

                        OutlinedTextField(
                            value = maintenanceCostInput,
                            onValueChange = { text ->
                                // Filter to allow English numbers only
                                val filtered = text.replace(Regex("[^0-9]"), "")
                                maintenanceCostInput = filtered
                            },
                            label = { Text("تكلفة الصيانة والتشغيل (ر.ي)") },
                            placeholder = { Text("0") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = partsCostInput,
                            onValueChange = { text ->
                                val filtered = text.replace(Regex("[^0-9]"), "")
                                partsCostInput = filtered
                            },
                            label = { Text("سعر قطع الغيار المستبدلة (ر.ي)") },
                            placeholder = { Text("0") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = programmingCostInput,
                            onValueChange = { text ->
                                val filtered = text.replace(Regex("[^0-9]"), "")
                                programmingCostInput = filtered
                            },
                            label = { Text("تكلفة البرمجة والإعداد السحابي (ر.ي)") },
                            placeholder = { Text("0") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                // Delivery date and notes
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "مواعيد التسليم وملاحظات الورشة",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium
                        )

                        // Custom DatePicker dialogue activation
                        OutlinedTextField(
                            value = formattedDeliveryDate,
                            onValueChange = {},
                            label = { Text("تاريخ تسليم القطعة المتوقع *") },
                            readOnly = true,
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "اختر التاريخ",
                                    modifier = Modifier.clickable {
                                        val calendar = Calendar.getInstance()
                                        calendar.timeInMillis = deliveryDate
                                        val year = calendar.get(Calendar.YEAR)
                                        val month = calendar.get(Calendar.MONTH)
                                        val day = calendar.get(Calendar.DAY_OF_MONTH)

                                        DatePickerDialog(
                                            context,
                                            { _, mYear, mMonth, mDay ->
                                                val newDate = Calendar.getInstance()
                                                newDate.set(mYear, mMonth, mDay)
                                                deliveryDate = newDate.timeInMillis
                                            },
                                            year, month, day
                                        ).show()
                                    }
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val calendar = Calendar.getInstance()
                                    calendar.timeInMillis = deliveryDate
                                    val year = calendar.get(Calendar.YEAR)
                                    val month = calendar.get(Calendar.MONTH)
                                    val day = calendar.get(Calendar.DAY_OF_MONTH)

                                    DatePickerDialog(
                                        context,
                                        { _, mYear, mMonth, mDay ->
                                            val newDate = Calendar.getInstance()
                                            newDate.set(mYear, mMonth, mDay)
                                            deliveryDate = newDate.timeInMillis
                                        },
                                        year, month, day
                                    ).show()
                                }
                        )

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("ملاحظات إضافية / عيوب القطعة") },
                            placeholder = { Text("اكتب أي شروط إضافية أو ميزات تالفة للقطعة المستلمة (اختياري)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        // Status Selection (only make visible or editable as segmented tabs)
                        Text(
                            text = "حالة طلب الصيانة",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        
                        val statuses = listOf("قيد الصيانة", "جاهز للتسليم", "تم التسليم")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            statuses.forEach { st ->
                                val isSelected = status == st
                                val activeCol = when (st) {
                                    "قيد الصيانة" -> ColorPending
                                    "جاهز للتسليم" -> ColorReady
                                    "تم التسليم" -> ColorDone
                                    else -> MaterialTheme.colorScheme.primary
                                }

                                FilterChip(
                                    selected = isSelected,
                                    onClick = { status = st },
                                    label = { Text(st, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = activeCol,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // Dynamic Total Summary displaying to the user
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "إجمالي التكاليف المسجلة:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "سيتم التمويه ويظهر الإجمالي فقط بالفاتورة للزبون",
                                fontSize = 10.sp,
                                color = ColorMuted
                            )
                        }
                        Text(
                            text = "${formatEnglishNumber(totalCost.toInt())} ريال يمني",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                if (showValidationError) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Text(
                            text = "يرجى تعبئة الحقول المطلوبة (*) لحفظ الفاتورة بنجاح",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                // Action Confirm Button
                Button(
                    onClick = {
                        if (customerName.trim().isEmpty() || deviceDescription.trim().isEmpty()) {
                            showValidationError = true
                        } else {
                            if (editingInvoice == null) {
                                viewModel.createInvoice(
                                    customerName = customerName.trim(),
                                    deviceDescription = deviceDescription.trim(),
                                    maintenanceCost = maintenanceCost,
                                    partsCost = partsCost,
                                    programmingCost = programmingCost,
                                    deliveryDate = deliveryDate,
                                    notes = notes.trim(),
                                    status = status,
                                    onComplete = onNavigateBack
                                )
                            } else {
                                val updated = editingInvoice.copy(
                                    customerName = customerName.trim(),
                                    deviceDescription = deviceDescription.trim(),
                                    maintenanceCost = maintenanceCost,
                                    partsCost = partsCost,
                                    programmingCost = programmingCost,
                                    deliveryDate = deliveryDate,
                                    notes = notes.trim(),
                                    status = status
                                )
                                viewModel.updateInvoice(updated, onComplete = onNavigateBack)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (editingInvoice == null) "حفظ وإصدار الفاتورة" else "تحديث الفاتورة وتعديلها",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
