package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Palette
val SlateDark = Color(0xFF0F172A)
val CardDark = Color(0xFF1E293B)
val CyanPrimary = Color(0xFF0EA5E9)
val CyanAccent = Color(0xFF38BDF8)
val TextLight = Color(0xFFF8FAFC)

// Light Palette
val SlateLight = Color(0xFFF8FAFC)
val CardLight = Color(0xFFFFFFFF)
val PrimaryLight = Color(0xFF0284C7)
val SecondaryLight = Color(0xFF0369A1)
val TextDark = Color(0xFF0F172A)

// Status colors
val ColorPending = Color(0xFFF59E0B) // Amber
val ColorReady = Color(0xFF10B981) // Emerald
val ColorDone = Color(0xFF3B82F6) // Blue
val ColorMuted = Color(0xFF64748B) // Slate grey

